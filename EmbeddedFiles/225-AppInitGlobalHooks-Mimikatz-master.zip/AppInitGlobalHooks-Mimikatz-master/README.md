# AppInitGlobalHooks-Mimikatz
Hide Mimikatz From Process Lists 

Adapted From This:
http://www.codeproject.com/Articles/49319/Easy-way-to-set-up-global-API-hooks?display=Print

Updated to x64 and Changed Calc.exe To Mimikatz.exe


